//https://docs.aws.amazon.com/iot/latest/developerguide/managing-device-certs.html
#define AMAZON_IOT_ROOT_CA_PEM                                          \
"-----BEGIN CERTIFICATE----- \r\n"                                      \
"MIIE0zCCA7ugAwIBAgIQGNrRniZ96LtKIVjNzGs7SjANBgkqhkiG9w0BAQUFADCB\r\n"  \
"yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL\r\n"  \
"ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp\r\n"  \
"U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW\r\n"  \
"ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0\r\n"  \
"aG9yaXR5IC0gRzUwHhcNMDYxMTA4MDAwMDAwWhcNMzYwNzE2MjM1OTU5WjCByjEL\r\n"  \
"MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW\r\n"  \
"ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJpU2ln\r\n"  \
"biwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxWZXJp\r\n"  \
"U2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0aG9y\r\n"  \
"aXR5IC0gRzUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCvJAgIKXo1\r\n"  \
"nmAMqudLO07cfLw8RRy7K+D+KQL5VwijZIUVJ/XxrcgxiV0i6CqqpkKzj/i5Vbex\r\n"  \
"t0uz/o9+B1fs70PbZmIVYc9gDaTY3vjgw2IIPVQT60nKWVSFJuUrjxuf6/WhkcIz\r\n"  \
"SdhDY2pSS9KP6HBRTdGJaXvHcPaz3BJ023tdS1bTlr8Vd6Gw9KIl8q8ckmcY5fQG\r\n"  \
"BO+QueQA5N06tRn/Arr0PO7gi+s3i+z016zy9vA9r911kTMZHRxAy3QkGSGT2RT+\r\n"  \
"rCpSx4/VBEnkjWNHiDxpg8v+R70rfk/Fla4OndTRQ8Bnc+MUCH7lP59zuDMKz10/\r\n"  \
"NIeWiu5T6CUVAgMBAAGjgbIwga8wDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8E\r\n"  \
"BAMCAQYwbQYIKwYBBQUHAQwEYTBfoV2gWzBZMFcwVRYJaW1hZ2UvZ2lmMCEwHzAH\r\n"  \
"BgUrDgMCGgQUj+XTGoasjY5rw8+AatRIGCx7GS4wJRYjaHR0cDovL2xvZ28udmVy\r\n"  \
"aXNpZ24uY29tL3ZzbG9nby5naWYwHQYDVR0OBBYEFH/TZafC3ey78DAJ80M5+gKv\r\n"  \
"MzEzMA0GCSqGSIb3DQEBBQUAA4IBAQCTJEowX2LP2BqYLz3q3JktvXf2pXkiOOzE\r\n"  \
"p6B4Eq1iDkVwZMXnl2YtmAl+X6/WzChl8gGqCBpH3vn5fJJaCGkgDdk+bW48DW7Y\r\n"  \
"5gaRQBi5+MHt39tBquCWIMnNZBU4gcmU7qKEKQsTb47bDN0lAtukixlE0kF6BWlK\r\n"  \
"WE9gyn6CagsCqiUXObXbf+eEZSqVir2G3l6BFoMtEMze/aiCKm0oHw0LxOXnGiYZ\r\n"  \
"4fQRbxC1lfznQgUy286dUV4otp6F01vvpX1FQHKOtw5rDgb7MzVIcbidJ4vEZV8N\r\n"  \
"hnacRHr2lVz2XTIIM6RUthg/aFzyQkqFOFSDX9HoLPKsEdao7WNq\r\n"  \
"-----END CERTIFICATE----- "


#define CELINT_KEY_CRT_PEM                                              \
"-----BEGIN CERTIFICATE----- \r\n"                                      \
"MIIDWTCCAkGgAwIBAgIUOxqZm53X34Pw6wXIFHQP3hhI//cwDQYJKoZIhvcNAQEL\r\n"  \
"BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\r\n"  \
"SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTE4MDQxODA1MjI1\r\n"  \
"MVoXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0\r\n"  \
"ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANNMBbq6Yv5F5CHUxvLC\r\n"  \
"kVfEIFO+FU/ul8IfcMuyjBIVjbSZnpEEq0xT+vOGApcJDd+tinI74TfCLgNq6udc\r\n"  \
"ZpXRVcIz7dyTuon3u2seGpO1tWcldThSC8yH/UgXoWzhLenm27sRuoFgRG8ycV41\r\n"  \
"MKsTDJ6tRD03YedpbtlhXoDaSrIgMfe14HPPPrpFrvKXsJemxgGJ6SoCoE7p9gtq\r\n"  \
"bmMw4mf2ANfw1Z03RUsGo3U6R2SuPyaVcD7mEAb8kUlLXVjTOtcYdisHtYwvG9cz\r\n"  \
"Hd+O4lCQnJcc4Gq3ymYcDscaRF89WPl4l+TRYVDkwjWNSbbAWQlgMt+MHHyk7RV3\r\n"  \
"UosCAwEAAaNgMF4wHwYDVR0jBBgwFoAUVs49vdwIyaksg9He1GLbvXGU28UwHQYD\r\n"  \
"VR0OBBYEFB1Ea51tmfGjtpo0lF5KrYb/CyO5MAwGA1UdEwEB/wQCMAAwDgYDVR0P\r\n"  \
"AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQAOLJBCRQcsU86bPe2pau4iDtFs\r\n"  \
"aN/2WZzgEaTxWQKpjotiDFJboMAdyG0Lj7dj37kM7XAt/ORds2zmncGBtwtzz5OH\r\n"  \
"QCaAGjRpB5ixEiv9qGabJAa8kDGc8T/kf0xqAubOQ1j9UWB12oNKeQIr/ZJhZWuC\r\n"  \
"EoP9Wf41mCwwJm3INxOcHZSczzK3iO5q5NhUQb/iHIz36TNes1cM7arN+04G7Pwb\r\n"  \
"4/Ix4z5VjwOxIieTXb7pn9hVLmuAg8iTeeFzTe4Six+x3sU6ghHC+jl6ZAKCwuyT\r\n"  \
"MUmy6GXEb9AhAiT6JO0WLYSS8sQFB8z1h1e6cK2ew0ibKWVglDCGcyNOlnn1\r\n"  \
"-----END CERTIFICATE-----"


#define CELINT_KEY_PEM                                                  \
"-----BEGIN RSA PRIVATE KEY-----\r\n"                                   \
"MIIEowIBAAKCAQEA00wFurpi/kXkIdTG8sKRV8QgU74VT+6Xwh9wy7KMEhWNtJme\r\n"  \
"kQSrTFP684YClwkN362KcjvhN8IuA2rq51xmldFVwjPt3JO6ife7ax4ak7W1ZyV1\r\n"  \
"OFILzIf9SBehbOEt6ebbuxG6gWBEbzJxXjUwqxMMnq1EPTdh52lu2WFegNpKsiAx\r\n"  \
"97Xgc88+ukWu8pewl6bGAYnpKgKgTun2C2puYzDiZ/YA1/DVnTdFSwajdTpHZK4/\r\n"  \
"JpVwPuYQBvyRSUtdWNM61xh2Kwe1jC8b1zMd347iUJCclxzgarfKZhwOxxpEXz1Y\r\n"  \
"+XiX5NFhUOTCNY1JtsBZCWAy34wcfKTtFXdSiwIDAQABAoIBAQCgsrnMyQKO5jLZ\r\n"  \
"9AyXBpkpidUYO4HT997dWbIciZ90BYZva0IogseQ1nIOkcYYfl9Z1Y9sz9O652i9\r\n"  \
"Wqxq52Bx4vJ5L6tgzc3aLloQ3qVR36mmV9utyOCGXoqoMKipuRyFPvmwbYxN5xxF\r\n"  \
"AbUs9AEequ83Iwm6EQvZxtryYtZP4dOTnlKiURcvquFjYojWc5hnly+ra2GCtkf5\r\n"  \
"FuyIXbwEjXQe7LLX3VWWuey/yI6LxUhMnhSPjOjsd0HZTSXwlcHkP6M0AwKMet4N\r\n"  \
"ATdGCrm7aAtH9BJIE9T0g/Fnu854RnqO67VWr3HmwNHTaXd9tKfvPddi3FWJ3EUR\r\n"  \
"XIR/qCf5AoGBAOpfo2VNzD6TbCz3L/MOPZqcl/HiIVv053QAY6AryRX3F4c90yTr\r\n"  \
"sISYGYFoqBznRxsyndQYoxqU42o85fH7KZJwb/2F5K9wtxL9N2JOBDXgGdMMp98a\r\n"  \
"SnJiog0iM2VvwFXCYF2qiz46GxFirurWtbM62tL4JSbxTUoOY2ziX40HAoGBAObL\r\n"  \
"ROl2vihWIJJX+Kre9j2DNA8eRzfujV8Qr7GICZDTY6gxvRKO3tH3oEwjDqRH3PlT\r\n"  \
"71iCg4Uufu4VKcS+ahi4ViKLW4brTm3KYYr/ADhSM5C5/KWILBidshlOa+DTjatN\r\n"  \
"PymdFa+3bO3tR3gO+C78hEH0GZfL8oPRqvDpN3FdAoGAePU438yB732oI6DDB16/\r\n"  \
"Hm9Y38YDz3CajzywLfbLBeILK4oV0YUuCZByAV6g/KHECd5apB6+9rYGlEqvpe4o\r\n"  \
"62HJ+n7ComS6pzs1/S8kbyWkTk7GyJbJ+zS6S6rt+ZjuG5SApXah/FCCrbtPaPW8\r\n"  \
"uq5SRvU4P1vjtqesWoKOK7sCgYAKctNo2mZbfyK0XWU1nyh4unLl6FIDFzqxPhkm\r\n"  \
"KWl9dASD/dR4fZ1a1iIcsE2eZF59ry4bzLTVl7hJYQ3mCVTWT6oeoD6Bii+fytTF\r\n"  \
"rSu+YQJSoAjvGY4dgy4n9SPvJsS4J6QfZywvK1e0IdTle5AC2I3ISpvKAoK1Mw3R\r\n"  \
"IE3RRQKBgAxd2FwBRyK8IMMWbY5Cf49cXTwn4kwYBKUmWVsgP9wAkktk8IgGFfCJ\r\n"  \
"wk8LYEe6Mb0C6dCrXdIQ1ZfXx/AcQBoenNkPfAncn/zYKSFrOOAPTNeyAvGcZk4m\r\n"  \
"FiShlON7eJ3IkfIzvetnfy7VRtWRcvM8fuMWnE1F6cZKjvMwRCEB\r\n"  \
"-----END RSA PRIVATE KEY-----\r\n"  \
