#define MQTT_TOPIC "ITS5900/iot_prj02_sensor"

// Debug levels on (1) or off (0)
#define DBGLVL0         1 // Human action info
#define DBGLVL1         1 // System action info
#define DBGLVL2         1 // State changne info
